#!/bin/bash
# TrustPass macOS launcher — equivalent to the Windows Start TrustPass.bat

set -u

# Always run from the folder containing this launcher.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# macOS normally provides Python as python3.
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python was not found. Install Python 3.10 or newer, then run this file again."
  echo "Download: https://www.python.org/downloads/macos/"
  read -r -p "Press Return to close..."
  exit 1
fi

if [ ! -f "$SCRIPT_DIR/backend/server.py" ]; then
  echo "Could not find backend/server.py."
  echo "Place this launcher in the main TrustPass project folder."
  read -r -p "Press Return to close..."
  exit 1
fi

# If port 8000 is not already listening, start the backend in a new Terminal window.
if ! lsof -nP -iTCP:8000 -sTCP:LISTEN >/dev/null 2>&1; then
  osascript - "$SCRIPT_DIR" <<'APPLESCRIPT'
on run argv
  set projectFolder to item 1 of argv
  tell application "Terminal"
    activate
    do script "cd " & quoted form of projectFolder & " && python3 backend/server.py"
  end tell
end run
APPLESCRIPT

  # Give the local server the same short startup delay as the Windows launcher.
  sleep 2
fi

# Open the TrustPass local site in the default browser.
open "http://127.0.0.1:8000"
